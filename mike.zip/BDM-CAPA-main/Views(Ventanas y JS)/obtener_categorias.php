<?php
require_once 'conexion.php';

try {
   
    $conexion = new conexion();
    $pdo = $conexion->conectar();

    if ($pdo) {
    
        $query = $pdo->prepare("CALL sp_obtener_categorias()");
        $query->execute();

        // Obtener resultados
        $categorias = $query->fetchAll(PDO::FETCH_ASSOC);

        // Devolver los resultados en formato JSON
        echo json_encode($categorias);
    } else {
        echo json_encode(['error' => 'No se pudo conectar a la base de datos.']);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>

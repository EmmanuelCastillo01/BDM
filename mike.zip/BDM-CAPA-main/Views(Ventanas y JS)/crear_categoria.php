<?php
session_start();
include 'conexion.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Categorías</title>

    <link rel="stylesheet" href="CSS/bootstrapCSS/bootstrap.min.css">
    <link rel="stylesheet" href="CSS/CrearCategoria.css">
    <script src="https://kit.fontawesome.com/f9a8a486b8.js" crossorigin="anonymous"></script>
</head>
<body class="d-flex flex-column min-vh-100">

    <div class="container conLogo">
        <h1 class="titulos">A&B Cursos Online</h1>
    </div>

    <!-- Navbar -->
    <div class="container card">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarOpciones" aria-controls="navbarOpciones" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarOpciones">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item border-end">
                            <a class="nav-link active textos-2" aria-current="page" href="landPageAdmin.html"> Principal </a>
                        </li>
                        <li class="nav-item border-end">
                            <a class="nav-link active textos-2" aria-current="page" href="CrearCategoria.html"> Gestionar Categorías </a>
                        </li>
                        <li class="nav-item border-end">
                            <a class="nav-link active textos-2" aria-current="page" href="reportUsers.html"> Reporte de Usuarios </a>
                        </li>
                        <li class="nav-item dropdown border-end">
                            <a class="nav-link dropdown-toggle textos-2" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Categorías
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item textos-2" href="Busqueda.html"> Arte </a></li>
                                <li><a class="dropdown-item textos-2" href="Busqueda.html"> Matemáticas </a></li>
                                <li><a class="dropdown-item textos-2" href="Busqueda.html"> Programación </a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active textos-2" aria-current="page" href="LandingPage.html"> Cerrar Sesión </a>
                        </li>
                    </ul>
                    
                    <form class="d-flex w-auto w-md-50 w-lg-50">
                        <input class="form-control me-2 textos-2" type="search" placeholder="Escribe algo.." aria-label="Buscar">
                        <button class="btn btn-outline-dark textos-2" type="submit"> Buscar </button>
                    </form>
                </div>
            </div>
        </nav>
    </div>

    <div class="container">
        <h2>Categorías</h2>

        <!-- Lista de categorías -->
        <div class="category-list" id="categoryList"></div>

        <div class="button-container">
            <!-- Botón para crear una nueva categoría -->
            <button id="createCategory" type="submit" class="ca_btn">Crear Categoría</button>

            <!-- Botón para abrir el formulario de gestión de categorías -->
            <button id="toggleAdmin" class="ca_btn">Gestión de Categorías</button>
        </div>

        <!-- Formulario para agregar categorías -->
    <form id="categoryForm" action="alta_categoria.php" method="POST" style="display: none;">
            <div class="form-group">
                <label for="categoryName">Nombre de la Categoría:</label>
                <input type="text" id="categoryName" name="nombre" placeholder="Ingrese el nombre de la categoría" required>
            </div>
    
            <div class="form-group">
                <label for="categoryDescription">Descripción:</label>
                <textarea id="categoryDescription" name="descripcion" placeholder="Ingrese una descripción para la categoría" rows="4" required></textarea>
            </div>

            <button type="submit" class="btn btn-success">Agregar Categoría</button>
    </form>

    </div>

    <footer class="footer1">
        <div class="container">
            <p class="mb-0">© 2024 <strong>A&B Cursos Online</strong>. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script src="JS/bootstrapJS/bootstrap.bundle.min.js"></script>
    <script src="JS/CrearCategoria.js"></script> <!-- Archivo JS externo -->
</body>
</html>

<?php
//require_once 'conexion.php';
session_start();
include 'conexion.php';
$db = new conexion();
$conexion = $db->conectar();
// Verificar si el usuario está autenticado
if (!isset($_SESSION['id'])) {
    die(json_encode(['success' => false, 'message' => 'Usuario no autenticado']));
}

// Leer los datos enviados
$data = json_decode(file_get_contents('php://input'), true);

$id_categoria = $data['id'] ?? null;
$nombre = $data['nombre'] ?? null;
$descripcion = $data['descripcion'] ?? null;

// Validar los datos
if (!$id_categoria || !$nombre || !$descripcion) {
    die(json_encode(['success' => false, 'message' => 'Datos incompletos.']));
}

try {
    $stmt = $conexion->prepare("CALL sp_editar_categoria(:nombre, :descripcion, :id_categoria )");
    $stmt->bindValue(':id_categoria', $id_categoria, PDO::PARAM_INT);
    $stmt->bindValue(':nombre', $nombre, PDO::PARAM_STR);
    $stmt->bindValue(':descripcion', $descripcion, PDO::PARAM_STR);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Categoría editada correctamente']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al ejecutar el procedimiento.']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>


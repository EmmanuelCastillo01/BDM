<?php
session_start();
include 'conexion.php';

$db = new conexion();
$conexion = $db->conectar();

if ($conexion === null) {
    echo "No se pudo conectar a la base de datos.";
    exit;
}


// No se porque no entra a este if y se salta hasta el "Correo electrónico o contraseña incorrectos"
if (!isset($_POST['email']) || !isset($_POST['contrasena'])) {
    echo "Por favor, ingrese el correo electrónico y la contraseña.";
    exit;
}

$email = $_POST['email'];
$contrasena = $_POST['contrasena'];

try {
    // Llama al sp con los parametros Email, contra y @estado
    $stmt = $conexion->prepare("CALL sp_consultar_usuario(:email, :contrasena, @estado)");
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':contrasena', $contrasena);
    $stmt->execute();

    // Cierra el cursor para liberar el conjunto de resultados pendiente
    $stmt->closeCursor();

    // Consultar el valor del estado
    $result = $conexion->query("SELECT @estado AS estado")->fetch(PDO::FETCH_ASSOC);
    $estado = $result['estado'];

    

    // Verificar el estado de inicio de sesión y mostrar los mensajes

    if ($estado == 1/*Login exitoso*/ ) {
        $user_stmt = $conexion->prepare("SELECT id, nombre_usuario, telefono, tipo_usuario, email FROM usuario WHERE email = :email");
        $user_stmt->bindParam(':email', $email);
        $user_stmt->execute();
        $usuario = $user_stmt->fetch(PDO::FETCH_ASSOC);

        $_SESSION['id'] = $usuario['id'];
        $_SESSION['nombre_usuario'] = $usuario['nombre_usuario'];
        $_SESSION['telefono'] = $usuario['telefono'];
        $_SESSION['tipo_usuario'] = $usuario['tipo_usuario']; // 1 = admin, 2 = maestro, 3 = alumno
        $_SESSION['email'] = $usuario['email'];
        echo "Inicio de sesión exitoso.";
        header("Location: dashboard.php");
        exit;

    } elseif ($estado == 0 /*Contra/correo equivocado*/ ) {
        echo "Correo electrónico o contraseña incorrectos.";


    } elseif ($estado == -1/*Bloqueo de cuenta*/) {
        echo "La cuenta está bloqueada.";
    }
} catch (PDOException $e) {
    echo "Error en la consulta: " . $e->getMessage();
}
?>
<?php
require_once 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre_usuario = $_POST['nombre_usuario'];
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $telefono = $_POST['telefono'];
    $tipo_usuario = $_POST['tipo_usuario'];
    $foto = null;
    $biografia = isset($_POST['biografia']) ? $_POST['biografia'] : null;
    $cuenta_bancaria = isset($_POST['cuenta_bancaria']) ? $_POST['cuenta_bancaria'] : null;

    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $foto = file_get_contents($_FILES['foto']['tmp_name']);
    }

    // Conectar a la base de datos
    $conexion = new conexion();
    $pdo = $conexion->conectar();

    if ($pdo) {
        try {
            $stmt = $pdo->prepare("CALL sp_crear_usuario(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            $stmt->bindParam(1, $nombre_usuario, PDO::PARAM_STR);
            $stmt->bindParam(2, $nombre, PDO::PARAM_STR);
            $stmt->bindParam(3, $apellidos, PDO::PARAM_STR);
            $stmt->bindParam(4, $correo, PDO::PARAM_STR);
            $stmt->bindParam(5, $contrasena, PDO::PARAM_STR);
            $stmt->bindParam(6, $tipo_usuario, PDO::PARAM_INT);
            $stmt->bindParam(7, $foto, PDO::PARAM_LOB);
            $stmt->bindParam(8, $fecha_nacimiento, PDO::PARAM_STR);
            $stmt->bindParam(9, $telefono, PDO::PARAM_INT);
            $stmt->bindParam(10, $biografia, PDO::PARAM_STR);
            $stmt->bindParam(11, $cuenta_bancaria, PDO::PARAM_STR);

            $stmt->execute();

            echo "Usuario registrado exitosamente.";
            header("Location: login.php");
        } catch (PDOException $e) {
            echo "Error al registrar usuario: " . $e->getMessage();
        }
    } else {
        echo "Error de conexión a la base de datos.";
    }
} else {
    echo "Método no permitido.";
}
?>

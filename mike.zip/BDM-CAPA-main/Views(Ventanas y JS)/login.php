<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/f9a8a486b8.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="CSS/iniciosesion.css">

    <title>Registro e Inicio de Sesión</title>
</head>

<body>
    <div class="container">
        <div class="forms-container">
            <div class="signin-signup">

                <form action="validacion_usuario.php" class="sign-in-form" method="POST">
                    <h2 class="title">Inicia Sesión</h2>
                    
                    <div class="input-container1">
                        <div class="input-field">
                            <i class="fas fa-envelope"></i>
                            <input name="email" type="text" placeholder="Correo Electrónico" />
                        </div>

                        <div class="input-field">
                            <i class="fas fa-lock"></i>
                            <input name="contrasena" type="password" placeholder="Contraseña" />
                        </div>

                    </div>

                    <button type="submit" class="btn1 solid"> Inicia Sesión </button>

                    <p class="social-text">O Inicia Sesión mediante</p>

                    <div class="social-media">
                        <a href="#" class="social-icon">
                            <i class="fab fa-twitter"></i>
                        </a>

                        <a href="#" class="social-icon">
                            <i class="fab fa-google"></i>
                        </a>

                        <a href="#" class="social-icon">
                            <i class="fab fa-linkedin-in"></i>
                        </a>

                    </div>
                </form>

                <form action="alta_usuario.php" class="sign-up-form" method="POST" enctype="multipart/form-data">
                    <h2 class="title">Registro de Usuario</h2>
                
                    <div class="input-container">
                        <!-- Nombre -->
                        <div class="input-field">
                            <i>&nbsp;</i>
                            <input type="text"  name="nombre" placeholder="Nombre(s)" />
                        </div>
                
                        <!-- Apellidos -->
                        <div class="input-field">
                            <i>&nbsp;</i>
                            <input type="text" name="apellidos" placeholder="Apellidos" />
                        </div>
                
                        <!-- Nombre de Usuario -->
                        <div class="input-field">
                            <i class="fas fa-user"></i>
                            <input type="text" name="nombre_usuario" placeholder="Nombre de Usuario" />
                        </div>
                
                        <!-- Correo Electrónico -->
                        <div class="input-field">
                            <i class="fas fa-envelope"></i>
                            <input type="email" name="correo" placeholder="Correo Electrónico" />
                        </div>
                
                        <!-- Otros campos adicionales -->
                        <div class="input-field">
                            <i class="fa-regular fa-calendar"></i>
                            <input type="date" name="fecha_nacimiento" placeholder="Fecha de Nacimiento" />
                        </div>
                
                        <div class="input-field">
                            <i>&nbsp;</i>
                            <div class="input-wrapper">
                                <input type="text" name="genero" placeholder="Género" readonly />
                                <select class="form-select rounded-5" id="genero">
                                    <option value="" selected disabled>Selecciona</option>
                                    <option value="1">Hombre</option>
                                    <option value="2">Mujer</option>
                                    <option value="3">No Binario</option>
                                </select>
                            </div>
                        </div>
                
                        <div class="input-field">
                            <i>&nbsp;</i>
                            <div class="input-wrapper">
                                <input type="text" name="tipo_usuario" placeholder="Tipo de Usuario" readonly />
                                <select class="form-select rounded-5" id="tipo-usuario" name="tipo_usuario" >
                                   
                                    <option value="2">Instructor </option>
                                    <option value="3">Alumno</option>
                                </select>
                            </div>
                        </div>
                
                        <!-- Teléfono -->
                        <div class="input-field">
                            <i class="fa-solid fa-phone"></i>
                            <input type="number" name="telefono" placeholder="Teléfono" />
                        </div>

                        <!-- Contraseña -->
                        <div class="input-field">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="contrasena" placeholder="Contraseña" />
                        </div>

                        <!-- Contraseña -->
                        <div class="input-field">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="confirmar_contrasena" placeholder="Confirmar Contraseña" />
                        </div>

                    </div>

                    <label for="foto" class="form-label fs-3 subtitulos">Foto de Perfil</label>

                    <div class="img-container d-flex justify-content-center">
                        <span class="no-image-text">No hay foto seleccionada</span>
                        <img id="preview" class="img-preview rounded-5" alt="Foto de perfil seleccionada">
                    </div>

                    <div class="mb-3">
                        <input type="file" name="foto" class="form-control rounded-5" id="foto" accept="image/jpeg, image/png">
                    </div>
                    
                    <button type="submit" class="btn"> Registrarse </button>
                </form>
                
            </div>
        </div>

        <div class="panels-container">

            <div class="panel left-panel">

                <div class="content">
                    <h3>¿Aún no tienes una Cuenta?</h3>
                    <p>¿Qué esperas para crear una?</p>
                    <button class="btn transparent" id="sign-up-btn">Regístrate</button>
                </div>

                <img src="img/log.svg" class="image" alt="Log Image" />
            </div>

            <div class="panel right-panel">
                <div class="content">
                    <h3>¿Ya tienes Cuenta?</h3>
                    <p>¡Inicia Sesión para empezar a Aprender!</p>
                    <button class="btn transparent" id="sign-in-btn">Iniciar Sesión</button>
                </div>

                <img src="img/register.svg" class="image" alt="Register Image" />

            </div>

        </div>
    </div>

    <script src="JS/app.js"></script>
    <script src="JS/addUser.js"></script>
    
</body>
</html>

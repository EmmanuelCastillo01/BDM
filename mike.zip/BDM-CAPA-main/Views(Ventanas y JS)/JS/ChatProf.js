const chats = {
    "Oliver Smith": [
        { user: 'Profesor', text: '¡Hola! ¿En qué te puedo ayudar?', time: new Date().toLocaleString() },
        { user: 'Alumno', text: 'Tengo una pregunta sobre la tarea.', time: new Date().toLocaleString() }
    ],
    "Harry Osborn": [
        { user: 'Profesor', text: '¡Hola! ¿En qué te puedo ayudar?', time: new Date().toLocaleString() },
        { user: 'Alumno', text: '¿Cómo resuelvo el problema 3?', time: new Date().toLocaleString() }
    ],
    "Mary Jane": [
        { user: 'Profesor', text: '¡Hola! ¿En qué te puedo ayudar?', time: new Date().toLocaleString() },
        { user: 'Alumno', text: 'Quisiera repasar el último tema.', time: new Date().toLocaleString() }
    ]
};

const studentCourses = {
    "Oliver Smith": "Matemáticas Avanzadas",
    "Harry Osborn": "Física Moderna",
    "Mary Jane": "Química Orgánica"
};

const studentImages = {
    "Oliver Smith": "Users/User3.png",
    "Harry Osborn": "Users/User4.png",
    "Mary Jane": "Users/User5.png"
};

let currentChat = null; // No hay chat seleccionado al inicio

function openChat(studentName) {
    const chatTitle = document.getElementById('chat-title');
    const chatBox = document.getElementById('chat-box');
    const messageInput = document.querySelector('.message-input');
    const headerProfileImage = document.getElementById('header-profile-image');
    const courseInfo = document.getElementById('course-info');

    // Si el chat actual es el mismo que se está abriendo, cerrarlo
    if (currentChat === studentName) {
        currentChat = null;
        chatTitle.textContent = '¡Seleccione un Chat!'; // Texto por defecto
        chatBox.innerHTML = ''; // Limpiar mensajes
        messageInput.style.display = 'none'; // Ocultar el input y botón
        headerProfileImage.src = '';
        headerProfileImage.style.display = 'none'; // Ocultar imagen de perfil
        courseInfo.textContent = ''; // Limpiar información del curso
    } else {
        currentChat = studentName;
        chatTitle.textContent = studentName; // Mostrar el nombre del estudiante
        headerProfileImage.src = studentImages[studentName]; // Cambiar a la imagen específica del alumno
        headerProfileImage.style.display = 'block'; // Mostrar imagen de perfil
        courseInfo.innerHTML = `<span class="course-label">Curso:</span> ${studentCourses[studentName]}`; // Información del curso

        chatBox.innerHTML = "";

        // Agregar primero el mensaje del profesor (derecha) y luego el mensaje del alumno (izquierda)
        displayMessage(chats[studentName][0], studentName); // Mensaje del profesor
        displayMessage(chats[studentName][1], studentName); // Mensaje del alumno

        messageInput.style.display = 'flex'; // Mostrar el input y botón
    }
}

function displayMessage({ user, text, time }, studentName) {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    
    // Mostrar la imagen y el nombre específicos del alumno
    const imageSrc = user === 'Alumno' ? studentImages[studentName] : 'Users/User3.jpg';
    const userName = user === 'Alumno' ? studentName : 'Profesor';

    // Ajustar la alineación para los mensajes del alumno y del profesor
    messageElement.classList.add(user === 'Alumno' ? 'alumno-msg' : 'profesor-msg');
    
    // Cambiar la alineación de los mensajes del profesor a la izquierda
    messageElement.style.textAlign = 'left';
    
    messageElement.innerHTML = `
        <img src="${imageSrc}" alt="${user}" class="rounded-circle me-3" style="width: 40px; height: 40px;">
        <div class="message-content">
            <h6 class="mb-1 ${user === 'Alumno' ? 'alumno' : 'profesor'}">${userName}</h6>
            <p class="mb-0">${text}</p>
            <div class="message-time">${time}</div>
        </div>
    `;
    
    // Insertar el mensaje en el contenedor de mensajes
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight; // Desplazar hacia abajo
}


function sendMessage(event) {
    event.preventDefault();
    const input = document.getElementById('message-input');
    const message = input.value.trim();
    if (message && currentChat) { // Solo enviar si hay un chat seleccionado
        const messageData = { user: 'Profesor', text: message, time: new Date().toLocaleString() };
        chats[currentChat].push(messageData);
        displayMessage(messageData, currentChat); // Pasar currentChat como studentName
        input.value = "";
    }
}

// Inicializar sin chat seleccionado y ocultar el cuadro de entrada
document.getElementById('chat-title').textContent = '¡Bienvenid@ Profesor/a!';
document.querySelector('.message-input').style.display = 'none'; // Ocultar el input y botón al inicio

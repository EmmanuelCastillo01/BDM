const formularioRegistro = document.getElementById('formularioRegister'); //ACCEDEMOS AL FORMULARIO DEL REGISTRO
const BTNSubmit = document.getElementById('btn_Registrarse'); //ACCEDEMOS AL BOTÓN SUBMIT DEL REGISTRO
const inputs = document.querySelectorAll('#formularioRegister input'); //ACCEDEMOS A TODOS LOS INPUTS DEL REGISTRO

//VARIABLES PARA LOS ERRORES AL VALIDAR
var ERRORCONTRASEÑA = new Boolean (true);
var ERRORCORREO = new Boolean (true);


//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------


//FUNCION PARA VALIDAR EL CORREO
const validateEmail = (CorreoElectronico) => {
    debugger;
    return CorreoElectronico.value.trim().match(
        /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
};

const validate = () => {
    const email = $('#CorreoElectronico').val();

    if (validateEmail(CorreoElectronico)) {

        document.getElementById("ErrorMail").style.display = 'none'; //No mostrara el mensaje
        ERROREMAIL = true;
        return true;

    } else {
        document.getElementById('ErrorMail').style.display = 'block';
        ERROREMAIL = false;
    }
    return false;
}

$("#CorreoElectronico").on("input", validate)


//--------------------------------------------------------------------------------------------------------------------------------------------------


//FUNCION PARA VALIDAR LA CONTRASEÑA
function validarContraseña1(password){
   	
    //Variables
    var mayuscula = false;
    var minuscula = false;
    var numero = false;
    var caracter_raro = false;

    
    for(var i = 0;i<password.length;i++){
        if(password.charCodeAt(i) >= 65 && password.charCodeAt(i) <= 90){ //Letras mayusculas
            mayuscula = true;
        }
        else{
        }

        if(password.charCodeAt(i) >= 97 && password.charCodeAt(i) <= 122) //Letras minusculas
        {
            minuscula = true;
           
        }
        else{ 
        }

        if(password.charCodeAt(i) >= 48 && password.charCodeAt(i) <= 57) //Numeros
        {
            numero = true;
        }
        else
        {
            caracter_raro = true; //Cualquier signo 
        }
    }

    if(mayuscula === true && minuscula === true && caracter_raro === true && numero === true ){
        document.getElementById('ErrorContraseña').style.display = 'none'; //No mostrara el mensaje
        ERRORCONTRASEÑA = true;
        return true;
        
    }
    else{
        document.getElementById('ErrorContraseña').style.display = 'block';
        ERRORCONTRASEÑA = false;
    }

return false;
}


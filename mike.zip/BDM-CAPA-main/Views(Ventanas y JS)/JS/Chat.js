const chats = {
    "Curso de Arte": [{ user: 'Profesor', text: '¡Hola! ¿En qué te puedo ayudar?', time: new Date().toLocaleString() }],
    "Curso de Matemáticas": [{ user: 'Profesor', text: '¡Hola! ¿En qué te puedo ayudar?', time: new Date().toLocaleString() }],
    "Curso de Programación": [{ user: 'Profesor', text: '¡Hola! ¿En qué te puedo ayudar?', time: new Date().toLocaleString() }]
};

let currentChat = null; // No hay chat seleccionado al inicio

function openChat(chatName) {
    const chatTitle = document.getElementById('chat-title');
    const chatBox = document.getElementById('chat-box');
    const messageInput = document.querySelector('.message-input'); // Selecciona el contenedor del input y botón

    // Si el chat actual es el mismo que se está abriendo, cerrarlo
    if (currentChat === chatName) {
        currentChat = null;
        chatTitle.textContent = '¡Selecciona un Chat!'; // Texto por defecto
        chatBox.innerHTML = ''; // Limpiar mensajes
        messageInput.style.display = 'none'; // Ocultar el input y botón
    } else {
        currentChat = chatName;
        chatTitle.textContent = chatName;
        chatBox.innerHTML = "";
        chats[chatName].forEach(msg => displayMessage(msg));
        messageInput.style.display = 'flex'; // Mostrar el input y botón
    }
}

function displayMessage({ user, text, time }) {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    messageElement.classList.add(user === 'Alumno' ? 'alumno-msg' : 'profesor-msg');
    messageElement.innerHTML = `
        <img src="${user === 'Alumno' ? 'Users/User2.jpg' : 'Users/User3.jpg'}" alt="${user}" class="rounded-circle me-3" style="width: 40px; height: 40px;">
        <div class="message-content">
            <h6 class="mb-1 ${user === 'Alumno' ? 'alumno' : 'profesor'}">${user}</h6>
            <p class="mb-0">${text}</p>
            <div class="message-time">${time}</div>
        </div>
    `;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
}

function sendMessage(event) {
    event.preventDefault();
    const input = document.getElementById('message-input');
    const message = input.value.trim();
    if (message && currentChat) { // Solo enviar si hay un chat seleccionado
        const messageData = { user: 'Alumno', text: message, time: new Date().toLocaleString() };
        chats[currentChat].push(messageData);
        displayMessage(messageData);
        input.value = "";
    }
}

// Inicializar sin chat seleccionado y ocultar el cuadro de entrada
document.getElementById('chat-title').textContent = 'Selecciona un Chat :c';
document.querySelector('.message-input').style.display = 'none'; // Ocultar el input y botón al inicio

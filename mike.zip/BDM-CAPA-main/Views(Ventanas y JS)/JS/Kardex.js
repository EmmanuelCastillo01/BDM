window.onload = function() {
    // Desmarcar los checkboxes
    document.getElementById('activosBox').checked = false;
    document.getElementById('complBox').checked = false;

    // Llamar a la función de filtrado para mostrar todos los cursos al inicio
    filtrarCursos();
};

function filtrarCursos() {
    const fecha1 = document.getElementById('fecha1').value;
    const fecha2 = document.getElementById('fecha2').value;
    const categoriaSeleccionada = document.getElementById('categoriaID').value;
    const soloActivos = document.getElementById('activosBox').checked;
    const soloCompletados = document.getElementById('complBox').checked;

    const filas = document.querySelectorAll('#cursosTable tr');

    filas.forEach(fila => {
        let mostrar = true;

        const estatus = fila.dataset.estatus;
        const categoria = fila.dataset.categoria;
        const fechaInscripcion = fila.dataset.fechaInscripcion;

        // Filtrar por rango de fechas de inscripción
        if (fecha1 && new Date(fechaInscripcion) < new Date(fecha1)) {
            mostrar = false;
        }
        if (fecha2 && new Date(fechaInscripcion) > new Date(fecha2)) {
            mostrar = false;
        }

        // Filtrar por categoría
        if (categoriaSeleccionada !== 'Todas' && categoria !== categoriaSeleccionada) {
            mostrar = false;
        }

        // Filtrar por estatus de curso
        if (soloActivos && soloCompletados) {
            // Si ambos están seleccionados, mostrar solo los activos y completados
            if (estatus !== 'Activo' && estatus !== 'Completado') {
                mostrar = false;
            }
        } else if (soloActivos) {
            // Si solo "Activo" está seleccionado
            if (estatus !== 'Activo') {
                mostrar = false;
            }
        } else if (soloCompletados) {
            // Si solo "Completado" está seleccionado
            if (estatus !== 'Completado') {
                mostrar = false;
            }
        }

        fila.style.display = mostrar ? '' : 'none';
    });
}

function showLevel(level) {
    // Oculta todos los niveles
    const levels = document.querySelectorAll('.level-content');
    levels.forEach(l => l.style.display = 'none');

    // Muestra el nivel seleccionado
    document.getElementById(`level-${level}`).style.display = 'block';
}


function toggleMaterial(materialId) {
    const material = document.getElementById(materialId);
    if (material.style.display === "none") {
        material.style.display = "block";
    } else {
        material.style.display = "none";
    }
}
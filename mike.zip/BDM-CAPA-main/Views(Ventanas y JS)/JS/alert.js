
function Bien(){

    Swal.fire({
        title: "Bien!",
        text: "Funcionó Bien!",
        icon: "success"
      });
}


function aprobado(){

    Swal.fire({
        title: "Bien!",
        text: "Se aprobó el producto!",
        icon: "success"
      });
}

function desaprobado(){

    Swal.fire({
        title: ":(",
        text: "se rechazó el producto!",
        icon: "error"
      });
}


function Eliminar(){

    Swal.fire({
        title: "¿Desea Eliminar?",
        text: "No se podrá revertir",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then((result) => {
        if (result.isConfirmed) {
          Swal.fire({
            title: "Deleted!",
            text: "Your file has been deleted.",
            icon: "success"
          });
        }
      });
}


function Registro(){

    Swal.fire({
        position: "top-end",
        icon: "success",
        title: "Se ha iniciado correctamente",
        showConfirmButton: false,
        timer: 150
      });

      window.location.href='Inicio.html';
}


function Sesion(){

    Swal.fire({
        title: "¿Desea Salir?",
        text: "...",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "SALIR!"
      }).then((result) => {
        if (result.isConfirmed) {
          Swal.fire({
            title: "Deleted!",
            text: "Your file has been deleted.",
            icon: "success"
          });
          window.location.href='Registro-Inicio.html';

        }
      });
}



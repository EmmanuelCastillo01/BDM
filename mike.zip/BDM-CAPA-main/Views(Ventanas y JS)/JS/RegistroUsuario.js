
const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});


//const formularioRegistro = document.getElementById('formularioRegister'); //ACCEDEMOS AL FORMULARIO DEL REGISTRO
const BTNSubmit = document.getElementById('btn_Registrarse'); //ACCEDEMOS AL BOTÓN SUBMIT DEL REGISTRO
const inputs = document.querySelectorAll('#formularioRegister input'); //ACCEDEMOS A TODOS LOS INPUTS DEL REGISTRO

//VARIABLES PARA LOS ERRORES AL VALIDAR
var ERRORFECHA = new Boolean (true);
var ERRORCONTRASEÑA = new Boolean (true);
var ERRORCONTRA2 = new Boolean (true);
var ERRORCORREO = new Boolean (true);
var ERROREMAIL = new Boolean (true);
var IMAGEN = new Boolean (false);
var esValido = new Boolean (true);

//----------------------------------------------------------------------------------------------------------------


//FUNCION PARA CARGAR LA IMAGEN
function preview() {
    frame.src=URL.createObjectURL(event.target.files[0]);
    
}

//----------------------------------------------------------------------------------------------------------------


//FUNCIÓN PARA VALIDAR SÓLO LETRAS DEL NOMBRE Y APELLIDO
function SoloLetras(e) { 
    key = e.keyCode || e.which;  //Agarra el evento cuando presiono el teclado
    tecla = String.fromCharCode(key).toString();
    letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyÁÉÍÓÚáéíóúñÑ";

    especiales = [8, 13, 32, 164, 165]; //8 es para retroceder, el 13-ENTER, el 32-espacio, el 164-ñ, 165-Ñ
    tecla_especial = false;

    for (var i in especiales) {
        if (key === especiales[i]) {
            tecla_especial = true;
            break;
        }
    }

    if (letras.indexOf(tecla) === -1 && !tecla_especial) { //SI PONEMOS UN NÚMERO

        alert("¡ERROR! Ingresar SOLO LETRAS");

        return false;
    }
}


//----------------------------------------------------------------------------------------------------------------


//OBTENER LA FECHA DE HOY
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth() + 1; //ENERO ES 0
var yyyy = today.getFullYear();

if (dd < 10) {
    dd = '0' + dd; //ES PARA QUE SE GUARDE COMO "08"
}

if (mm < 10) {
    mm = '0' + mm; //ES PARA QUE SE GUARDE COMO "01"
}

today = yyyy + '-' + mm + '-' + dd; //LA FECHA DE HOY 


//----------------------------------------------------------------------------------------------------------------


//FUNCION PARA VALIDAR LA FECHA
function Fecha() {
 
    var fechaFormulario = document.getElementById("FechaNacimiento").value;
 
    if (fechaFormulario > today) {
        
        ERRORFECHA = false;
        document.getElementById('ErrorFecha').style.display = 'block'; //Muestra el mensaje de error
        
    }
    else {
        ERRORFECHA = true;
        document.getElementById('ErrorFecha').style.display = 'none'; //No muestra el mensaje
          
    }
}


//----------------------------------------------------------------------------------------------------------------


//FUNCION PARA VALIDAR EL CORREO
const validateEmail = (CorreoElectronico) => {
    debugger;
    return CorreoElectronico.value.trim().match(
        /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
};

const validate = () => {
    const email = $('#CorreoElectronico').val();

    if (validateEmail(CorreoElectronico)) {

        document.getElementById('ErrorMail').style.display = 'none'; //No mostrara el mensaje
        ERROREMAIL = true;
        return true;

    } else {
        document.getElementById('ErrorMail').style.display = 'block';
        ERROREMAIL = false;
    }
    return false;
}

$("#CorreoElectronico").on("input", validate)


//----------------------------------------------------------------------------------------------------------------



//FUNCION PARA VALIDAR LA CONTRASEÑA
function validarContraseña1(){
    //Variables
    var mayuscula = false;
    var minuscula = false;
    var numero = false;
    var caracter_raro = false;

     //Obtener el texto del imput contraseña
    var password = document.getElementById("ContraseñaRegistro").value;
    
    for(var i = 0; i<password.length; i++)
    {
        if(password.charCodeAt(i) >= 65 && password.charCodeAt(i) <= 90){ //Letras mayusculas
            mayuscula = true;
            
        }
       
        if(password.charCodeAt(i) >= 97 && password.charCodeAt(i) <= 122) //Letras minusculas
        {
            minuscula = true;
           
        }
        if(password.charCodeAt(i) >= 48 && password.charCodeAt(i) <= 57) //Numeros
        {
            numero = true;
        }
        if(password.charCodeAt(i) >= 33 && password.charCodeAt(i) <= 47) //Numeros
        {
            caracter_raro = true;
        }
      
       
    }

    if(mayuscula === true && minuscula === true && numero === true && caracter_raro === true && password.length === 8){
       // caracter_raro === true
        document.getElementById('ErrorContraseña').style.display = 'none'; //No mostrara el mensaje
        ERRORCONTRASEÑA = true;
       
        
    }
    else{
        document.getElementById('ErrorContraseña').style.display = 'block';
        ERRORCONTRASEÑA = false;
        
    }

}


//----------------------------------------------------------------------------------------------------------------


//VALIDAR CONTRASEÑAS SI SON IGUALES
const validarContraseña2 = () => {
    const Contraseña1 = document.getElementById('ContraseñaRegistro');
    const Contraseña2 = document.getElementById('ContraseñaSecundaria');

    if (Contraseña1.value !== Contraseña2.value) { //Devuelve true si los operandos son del mismo tipo pero no iguales, o son de diferente tipo.

        document.getElementById('ErrorContra2').style.display = 'block'; //Me da pendiente, en REVISION
        ERRORCONTRA2 = false;
        
    }
    else {

        document.getElementById('ErrorContra2').style.display = 'none';
        ERRORCONTRA2 = true;
       
    }
}


//----------------------------------------------------------------------------------------------------------------


//VALIDAR EL FORMULARIO
const validarFormulario = (e) => 
{
    switch (e.target.name)
     {//Identifica el nombre del INPUT
       
        case "fecha-Nacimiento":
            Fecha();
            break;
 
        case "passwordRegister":
            validarContraseña1(); 
            break;
            
        case "password2":
            validarContraseña2();
            break;

        default:
            break;
    }
};


//----------------------------------------------------------------------------------------------------------------


//POR CADA INPUT EJECUTA LA FUNCIÓN
inputs.forEach((input) => { 
    input.addEventListener('keyup', validarFormulario);//Cuando suelte la tecla se ejecuta
    input.addEventListener('blur', validarFormulario);//Cuando de click en otro lugar se ejecuta

});


//----------------------------------------------------------------------------------------------------------------


formularioRegistro.addEventListener("submit", e=>{
     
    e.preventDefault();
  //  const password = document.getElementById('Contraseña').value; //Accedemos al INPUT contraseña
    //validarContraseña1(password);

    if (ERRORFECHA === true && ERRORCONTRASEÑA === true && ERRORCONTRA2 === true && ERROREMAIL === true) {
        //
      // Agregas la validación del «ReCaptcha».
      //formularioRegistro.submit();
      alert(" ¡Te has registrado correctamente! :D ");
      formularioRegister.reset();
      formularioLogin.reset();
      
      // Envías el formulario en caso de cumplir el «IF»
    } else {
      alert("Por favor de revisar que haya ingresado todos los datos correctamente ");  
    }
  });
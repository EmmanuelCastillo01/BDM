    // Variables y referencias
    const toggleAdminBtn = document.getElementById('toggleAdmin');
    const createCategoryBtn = document.getElementById('createCategory');
    const categoryForm = document.getElementById('categoryForm');
    const categoryList = document.getElementById('categoryList');
    const addEditButton = categoryForm.querySelector('button[type="submit"]'); // Referencia al botón de agregar/editar
    let editMode = false;
    let categoryToEdit = null;

    // Inicializa las categorías
    function initializeCategories() {
        const categories = [
            { name: "Arte", description: "Incluye cursos de pintura, escultura y diseño." },
            { name: "Programación", description: "Incluye cursos de HTML, CSS, JavaScript y más." },
            { name: "Matemáticas", description: "Incluye cursos de álgebra, geometría y cálculo." },
        ];

    categories.forEach((category, index) => {
        addCategoryToDOM(category.name, category.description, index + 1); // Asigna un `id` incremental
    });
    }


    // Función para cargar las categorías desde la base de datos
    async function loadCategories() {
        try {
            const response = await fetch('obtener_categorias.php');
            const categories = await response.json();

            if (categories.error) {
                console.error(categories.error);
                return;
            }

            // Agregar cada categoría al DOM
            categories.forEach(category => {
                addCategoryToDOM(category.nombre, category.descripcion, category.id);
            });
        } catch (error) {
            console.error('Error al cargar categorías:', error);
        }
    }
    /*async function loadCategories() {
        try {
            const response = await fetch('obtener_categorias.php');
            const categories = await response.json();

            if (categories.error) {
                console.error(categories.error);
                return;
            }

            // Agregar cada categoría al DOM
            categories.forEach(category => {
                addCategoryToDOM(category.nombre, category.descripcion);
            });
        } catch (error) {
            console.error('Error al cargar categorías:', error);
        }
    }*/

    // Llamar a la función al cargar la página
    window.onload = loadCategories;

    // Agrega una categoría al DOM
    function addCategoryToDOM(name, description,id) {
        const categoryItem = document.createElement('div');
        categoryItem.classList.add('category-item');
        categoryItem.dataset.id = id; 

        categoryItem.innerHTML = `
            <div>
                <strong>${name}</strong>
                <p>${description}</p>
                <p class="category-info">
                </p>
            </div>
            <div class="admin-options">
                <button class="btn btn-primary edit-btn">Editar</button>
                <button class="btn btn-danger delete-btn">Eliminar</button>
            </div>
        `;

        categoryList.appendChild(categoryItem);
    }


    // Alternar formulario y opciones de administrador
    toggleAdminBtn.addEventListener('click', () => {
        document.querySelectorAll('.admin-options').forEach(adminOption => {
            adminOption.style.display = adminOption.style.display === 'block' ? 'none' : 'block'; // Mostrar/ocultar
        });
    });

    // Mostrar el formulario para crear una nueva categoría
    createCategoryBtn.addEventListener('click', () => {
        if (categoryForm.style.display === 'block') {
            // Ocultar el formulario
            categoryForm.style.display = 'none';
        } else {
            // Mostrar el formulario y permitir el scroll de la página normalmente
            categoryForm.style.display = 'block';
            addEditButton.textContent = "Agregar Categoría"; // Resetear texto del botón a "Agregar Categoría"
        }
    });


    // Agregar nueva categoría
    categoryForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const name = document.getElementById('categoryName').value;
        const description = document.getElementById('categoryDescription').value;

        if (editMode) {
            // Editar categoría
            categoryToEdit.querySelector('strong').textContent = name;
            categoryToEdit.querySelector('p:nth-child(2)').textContent = description; // Cambiar a p:nth-child(2)
            editMode = false;
            categoryToEdit = null;
            addEditButton.textContent = "Agregar Categoría"; // Cambiar texto de vuelta
            alert('Categoría editada correctamente');
        } else {
            // Crear nueva categoría
            addCategoryToDOM(name, description);
            categoryForm.submit();
            alert('Categoría agregada correctamente');
        }

        // Limpiar el formulario
        categoryForm.reset();
        categoryForm.style.display = 'none'; // Ocultar el formulario después de agregar
    });

    // Delegación de eventos para Editar y Eliminar
    categoryList.addEventListener('click', function(event) {
        if (event.target.classList.contains('edit-btn')) {
            const categoryItem = event.target.closest('.category-item');
            const id = categoryItem.dataset.id; // ID de la categoría
            const name = categoryItem.querySelector('strong').textContent;
            const description = categoryItem.querySelector('p').textContent;
    
            console.log('Edit Mode Activated:', { id, name, description }); // Log para depuración
    
            document.getElementById('categoryName').value = name;
            document.getElementById('categoryDescription').value = description;
    
            categoryToEdit = categoryItem; // Guarda la referencia al elemento DOM
            editMode = true; // Activa el modo edición
    
            addEditButton.textContent = "Editar Categoría";
            categoryForm.style.display = 'block'; // Muestra el formulario
        }
    });
    categoryForm.addEventListener('submit', async function(event) {
        //event.preventDefault(); // Prevenir el comportamiento por defecto del formulario
    
        const name = document.getElementById('categoryName').value;
        const description = document.getElementById('categoryDescription').value;
    
        if (editMode) {
            const id = categoryToEdit.dataset.id; // Obtén el ID de la categoría a editar
            try {
                const response = await fetch('editar_categoria.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id, nombre: name, descripcion: description }),
                });
    
                const result = await response.json();
                console.log('Response:', result); // Log para depuración
    
                if (result.success) {
                    categoryToEdit.querySelector('strong').textContent = name;
                    categoryToEdit.querySelector('p').textContent = description;
                    alert('Categoría editada correctamente');
                } else {
                    alert('Error al editar la categoría: ' + result.message);
                }
            } catch (error) {
                console.error('Error al editar la categoría:', error);
            }
        } else {
            addCategoryToDOM(name, description); // Lógica de creación
            alert('Categoría agregada correctamente');
        }
    
        categoryForm.reset(); // Limpiar el formulario
        categoryForm.style.display = 'none'; // Ocultar el formulario
        editMode = false; // Resetear el modo de edición
    });
   
    /* if (event.target.classList.contains('edit-btn')) {
            // Editar categoría
            const categoryItem = event.target.closest('.category-item');
            const name = categoryItem.querySelector('strong').textContent;
            const description = categoryItem.querySelector('p:nth-child(2)').textContent; // Cambiar a p:nth-child(2)

            document.getElementById('categoryName').value = name;
            document.getElementById('categoryDescription').value = description;

            categoryToEdit = categoryItem;
            editMode = true;

            // Cambiar el texto del botón de agregar a editar
            addEditButton.textContent = "Editar Categoría";

            // Mostrar el formulario para editar
            categoryForm.style.display = 'block';
        }

        if (event.target.classList.contains('delete-btn')) {
            // Eliminar categoría
            const categoryItem = event.target.closest('.category-item');
            categoryList.removeChild(categoryItem);
            alert('Categoría eliminada correctamente');
        }*/

    // Inicializar categorías en el DOM
    initializeCategories();

// Simulando datos de ejemplo
const cursos = [
    { id: 1, nombre: "Curso de Matemáticas", fechaCreacion: "2024-01-15", categoria: "Matemáticas", alumnosInscritos: 25, ingresosTotales: 1500.50, activo: true },
    { id: 2, nombre: "Curso de Arte", fechaCreacion: "2024-02-20", categoria: "Arte", alumnosInscritos: 15, ingresosTotales: 750.00, activo: false },
    { id: 3, nombre: "Curso de Programación", fechaCreacion: "2024-03-10", categoria: "Programación", alumnosInscritos: 40, ingresosTotales: 2500.00, activo: true },
    // Agrega más cursos según sea necesario
];

const alumnos = [
    { curso: "Curso de Matemáticas", alumno: "Juan Pérez", nivel: "Intermedio", inscripcion: "2024-01-16", pago: 600.00, formaPago: "Tarjeta de Credito" },
    { curso: "Curso de Arte", alumno: "Ana Gómez", nivel: "Básico", inscripcion: "2024-02-21", pago: 500.00, formaPago: "PayPal" },
    { curso: "Curso de Programación", alumno: "Carlos Ruiz", nivel: "Avanzado", inscripcion: "2024-03-11", pago: 900.00, formaPago: "Tarjeta de Credito" },
    // Agrega más alumnos según sea necesario
];

// Función para formatear moneda
function formatCurrency(value) {
    return '$' + value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Función para formatear fecha
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('es-MX', options);
}

// Función para filtrar los cursos según criterios seleccionados
function filtrarCursos() {
    const fechaInicio = document.getElementById('fecha1').value;
    const fechaFin = document.getElementById('fecha2').value;
    const categoriaID = document.getElementById('categoriaID').value;
    const soloActivos = document.getElementById('activo').checked;

    const cursosFiltrados = cursos.filter(curso => {
        const fechaCurso = new Date(curso.fechaCreacion);
        const fechaInicioDate = new Date(fechaInicio);
        const fechaFinDate = new Date(fechaFin);
        
        // Comprobar si las fechas están dentro del rango
        const fechaValida = (!fechaInicio || fechaCurso >= fechaInicioDate) &&
                            (!fechaFin || fechaCurso <= fechaFinDate);
        
        // Filtrar por categoría
        const categoriaValida = (categoriaID === 'Todas' || curso.categoria === categoriaID);
        
        // Filtrar por estado activo
        const activoValido = (!soloActivos || curso.activo);
        
        return fechaValida && categoriaValida && activoValido;
    });

    mostrarResultados(cursosFiltrados);
}

// Función para mostrar los resultados en las tablas
function mostrarResultados(cursosFiltrados) {
    const tbodyCursos = document.querySelector('#tablaCursos tbody');
    const tbodyAlumnos = document.querySelector('#tablaAlumnos tbody');
    
    tbodyCursos.innerHTML = '';
    tbodyAlumnos.innerHTML = '';
    
    let totalIngresos = 0;

    cursosFiltrados.forEach(curso => {
        // Mostrar datos de cursos
        const row = `<tr>
            <td>${curso.id}</td>
            <td>${curso.nombre}</td>
            <td>${formatDate(curso.fechaCreacion)}</td>
            <td>${curso.categoria}</td>
            <td>${curso.alumnosInscritos}</td>
            <td>${formatCurrency(curso.ingresosTotales)}</td>
        </tr>`;
        tbodyCursos.innerHTML += row;

        // Sumar ingresos para el total
        totalIngresos += curso.ingresosTotales;

        // Mostrar datos de alumnos
        const alumnosCurso = alumnos.filter(alumno => alumno.curso === curso.nombre);
        alumnosCurso.forEach(alumno => {
            const rowAlumno = `<tr>
                <td>${alumno.curso}</td>
                <td>${alumno.alumno}</td>
                <td>${alumno.nivel}</td>
                <td>${formatDate(alumno.inscripcion)}</td>
                <td>${formatCurrency(alumno.pago)}</td>
                <td>${alumno.formaPago}</td>
            </tr>`;
            tbodyAlumnos.innerHTML += rowAlumno;
        });
    });

    // Mostrar total de ingresos
    document.getElementById('totalIngresos').innerText = `Ingresos: ${formatCurrency(totalIngresos)}`;
}

// Agregar evento de escucha a los filtros
document.getElementById('fecha1').addEventListener('change', filtrarCursos);
document.getElementById('fecha2').addEventListener('change', filtrarCursos);
document.getElementById('categoriaID').addEventListener('change', filtrarCursos);
document.getElementById('activo').addEventListener('change', filtrarCursos);

// Inicializar el reporte al cargar la página
document.addEventListener('DOMContentLoaded', mostrarResultados(cursos));

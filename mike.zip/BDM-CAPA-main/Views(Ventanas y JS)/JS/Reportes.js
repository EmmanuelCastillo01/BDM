const tipoUsuarioSelect = document.getElementById('tipoUsuario');
const cursosColumn = document.getElementById('cursosColumn');
const porcentajeColumn = document.getElementById('porcentajeColumn');
const tablaContenido = document.getElementById('tablaContenido');

tipoUsuarioSelect.addEventListener('change', function() {
    if (this.value === 'profesores') {
        cursosColumn.textContent = 'Cursos Ofrecidos';
        porcentajeColumn.textContent = 'Ganancias';
        tablaContenido.innerHTML = `
            <tr>
                <td>CatedráticoCurioso</td>
                <td>José Pino</td>
                <td>01/01/2023</td>
                <td>66</td>
                <td>$15,000.00</td>
            </tr>
            <tr>
                <td>MentorSabio</td>
                <td>Lucía Ramírez</td>
                <td>12/02/2023</td>
                <td>45</td>
                <td>$10,000.00</td>
            </tr>
            <tr>
                <td>MaestroMenteBrillante</td>
                <td>Andrés Torres</td>
                <td>30/03/2023</td>
                <td>30</td>
                <td>$8,500.00</td>
            </tr>
            <tr>
                <td>SeñoraHistoria</td>
                <td>Claudia Martínez</td>
                <td>25/04/2023</td>
                <td>50</td>
                <td>$12,000.00</td>
            </tr>
        `;
    } else {
        cursosColumn.textContent = 'Cursos Inscritos';
        porcentajeColumn.textContent = '% Cursos Terminados';
        tablaContenido.innerHTML = `
            <tr>
                <td>CactusCreativo</td>
                <td>José Aureliano</td>
                <td>02/01/2023</td>
                <td>4</td>
                <td>25%</td>
            </tr>
            <tr>
                <td>SushiAdicto</td>
                <td>María Pérez</td>
                <td>15/03/2023</td>
                <td>3</td>
                <td>50%</td>
            </tr>
            <tr>
                <td>Chocorrol</td>
                <td>Carlos Gómez</td>
                <td>10/06/2023</td>
                <td>2</td>
                <td>75%</td>
            </tr>
            <tr>
                <td>EsponjaDeTaquero</td>
                <td>Laura Sánchez</td>
                <td>20/08/2023</td>
                <td>1</td>
                <td>100%</td>
            </tr>
        `;
    }
});

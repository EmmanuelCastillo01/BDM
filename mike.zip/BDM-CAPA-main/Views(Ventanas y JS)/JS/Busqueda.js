document.addEventListener('DOMContentLoaded', function() {
    const buscarBtn = document.querySelector('.btn-primary');
    buscarBtn.addEventListener('click', buscarCursos);

    function buscarCursos() {
        const tituloCurso = document.getElementById('tituloCurso').value.toLowerCase();
        const usuarioPublicador = document.getElementById('usuarioPublicador').value.toLowerCase();
        const fechaInicio = document.getElementById('fechaInicio').value;
        const fechaFin = document.getElementById('fechaFin').value;
        const categoriaID = document.getElementById('categoriaID').value;

        const cursos = [
            { titulo: "Introducción a SQL", usuario: "John Doe", fecha: "2024-10-20", categoria: "Bases de Datos" },
            { titulo: "Matemáticas Básicas", usuario: "Juan", fecha: "2024-10-20", categoria: "Matemáticas" },
            { titulo: "Pintura Avanzada", usuario: "Ana", fecha: "2024-10-22", categoria: "Arte" },
            { titulo: "Programación en JavaScript", usuario: "Luis", fecha: "2024-11-01", categoria: "Programación" },
        ];

        const cursosFiltrados = cursos.filter(curso => {
            const cumpleTitulo = tituloCurso ? curso.titulo.toLowerCase().includes(tituloCurso) : true;
            const cumpleUsuario = usuarioPublicador ? curso.usuario.toLowerCase().includes(usuarioPublicador) : true;
            const cumpleFecha = (fechaInicio && fechaFin) ? (curso.fecha >= fechaInicio && curso.fecha <= fechaFin) : true;
            const cumpleCategoria = categoriaID === "Todas" || curso.categoria === categoriaID;

            return cumpleTitulo && cumpleUsuario && cumpleFecha && cumpleCategoria;
        });

        const contenedorCursos = document.querySelector('.rowCursos');
        contenedorCursos.innerHTML = '';

        if (cursosFiltrados.length > 0) {
            cursosFiltrados.forEach(curso => {
                const cursoHTML = `
                    <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                        <div class="curso-card">
                            <img class="img-fluid img-Card" src="IMG/sql.png" alt="Imagen del curso">
                            <div class="card-body">
                                <h4 class="card-title subtitulos">${curso.titulo}</h4>
                                <p class="subtitulos-categoria small">${curso.usuario} | ${curso.categoria}</p>
                                <p class="textos">Este es un curso de ${curso.categoria}</p>
                                <a href="CursoVer.html" class="btn btn-primary btn-sm">Ver Curso Completo</a>
                            </div>
                        </div>
                    </div>
                `;
                contenedorCursos.insertAdjacentHTML('beforeend', cursoHTML);
            });
        } else {
            contenedorCursos.innerHTML = `<p class="text-center mt-4">¡No hay cursos existentes :c!</p>`;
        }
    }
});

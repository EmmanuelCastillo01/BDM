// Mostrar el formulario de pago al hacer clic en "Comprar Curso"
document.getElementById("buyCurso").addEventListener("click", function() {
  var paymentForm = document.getElementById("paymentForm");
  if (paymentForm.style.display === "none" || paymentForm.style.display === "") {
      paymentForm.style.display = "block"; // Mostrar el formulario
  } else {
      paymentForm.style.display = "none"; // Ocultar el formulario si ya está visible
  }
});

// Ocultar el formulario de pago cuando se hace clic en "Cancelar"
document.getElementById("cancelPayment").addEventListener("click", function() {
  document.getElementById("paymentForm").style.display = "none";
});

// Mostrar el ticket de compra al confirmar el pago
document.getElementById("paymentInfoForm").addEventListener("submit", function(event) {
  event.preventDefault();

  // Obtener los valores del formulario de pago
  var nombre = document.getElementById("paymentName").value;
  var curso = document.querySelector('.titulos1').innerText; // Obtener el nombre del curso
  var total = document.getElementById("cursoPrecio").innerText; // Obtener el precio del curso
  var numeroTransaccion = Math.floor(Math.random() * 1000000000); // Número de transacción aleatorio

  // Mostrar los datos en el ticket
  document.getElementById("ticketNombre").textContent = nombre;
  document.getElementById("ticketCurso").textContent = curso;
  document.getElementById("ticketTotal").textContent = total;
  document.getElementById("ticketTransaccion").textContent = numeroTransaccion;

  // Mostrar el modal del ticket de compra
  var ticketModal = new bootstrap.Modal(document.getElementById('ticketModal'));
  ticketModal.show();

  // Ocultar el formulario de pago
  document.getElementById("paymentForm").style.display = "none";
});

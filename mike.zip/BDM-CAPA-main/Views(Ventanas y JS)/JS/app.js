const sign_in_btn = document.querySelector('#sign-in-btn');
const sign_up_btn = document.querySelector('#sign-up-btn');
const container = document.querySelector('.container');

sign_up_btn.addEventListener("click", () => {
    container.classList.add('sign-up-mode');
});

sign_in_btn.addEventListener('click', () => {
    container.classList.remove('sign-up-mode');
});

document.getElementById('foto').addEventListener('change', function(event) {
    const preview = document.getElementById('preview');
    const noImageText = document.querySelector('.no-image-text');
    const file = event.target.files[0];

    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
            noImageText.style.display = 'none'; // Oculta el texto
        }
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
        noImageText.style.display = 'block'; // Muestra el texto si no hay imagen
    }
});



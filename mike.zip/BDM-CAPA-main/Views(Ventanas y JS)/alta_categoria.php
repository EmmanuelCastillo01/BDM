<?php
session_start();
include 'conexion.php';

$db = new conexion();
$conexion = $db->conectar();

// Verifica si el usuario está autenticado
if (!isset($_SESSION['id'])) {
    die('Error: Usuario no autenticado');
}

$id_instructor = $_SESSION['id'];

// Recuperar los otros datos enviados desde el formulario
$nombre = $_POST['nombre'] ?? null;
$descripcion = $_POST['descripcion'] ?? null;

// Verificar que los datos necesarios están presentes
if (!$nombre || !$descripcion) {
    die('Error: Faltan datos para crear la categoría');
}

// Usar PDO para ejecutar el procedimiento almacenado
try {
    $stmt = $conexion->prepare("CALL sp_crear_categoria(:nombre, :descripcion, :id_instructor)");
    $stmt->bindValue(':nombre', $nombre, PDO::PARAM_STR);
    $stmt->bindValue(':descripcion', $descripcion, PDO::PARAM_STR);
    $stmt->bindValue(':id_instructor', $id_instructor, PDO::PARAM_INT);
    $stmt->execute();

    echo "Categoría creada correctamente.";
    echo "Nombre: $nombre, Descripción: $descripcion, ID Instructor: $id_instructor";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
/*require_once 'conexion.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $id_instructor = $_POST['id_instructor'];

    $conexion = new conexion();
    $pdo = $conexion->conectar();

    if ($pdo) {
        try {
            // Preparar y ejecutar el procedimiento almacenado
            $stmt = $pdo->prepare("CALL sp_crear_categoria(?, ?, ?)");
            $stmt->bind_param("ssi", $nombre, $descripcion, $id_instructor);
            if ($stmt->execute()) {
                echo "Categoría creada exitosamente.";
            } else {
                echo "Error al crear la categoría.";
            }
        } catch (PDOException $e) {
            echo "Error en la base de datos: " . $e->getMessage();
        }
    } else {
        echo "No se pudo establecer la conexión con la base de datos.";
    }
}*/
?>


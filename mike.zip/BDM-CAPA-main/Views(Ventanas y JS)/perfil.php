<?php
session_start();
include 'conexion.php';


if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}


$db = new conexion();
$conexion = $db->conectar();

if ($conexion === null) {
    echo "No se pudo conectar a la base de datos.";
    exit;
}

$email_usuario = $_SESSION['email'];

//Este filtro es lo que llama y quita los botones basicamente solo es un select pero se trae la informacion con la que pida el sp
$stmt = $conexion->prepare("CALL sp_filtro_usuario(:email)");
$stmt->bindParam(':email', $email_usuario);
$stmt->execute();
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    echo "Usuario no encontrado.";
    exit;
}


$nombre_usuario = $usuario['nombre_usuario'];
$telefono = $usuario['telefono'];
$rango = $usuario['tipo_usuario']; // 1 Admin, 2 Instructor-Profe, 3 Alumno
$email = $usuario['email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario</title>

    <link rel="stylesheet" href="CSS/bootstrapCSS/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/f9a8a486b8.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="CSS/perfil.css">
    <link rel="stylesheet" href="CSS/landPage.css">

</head>

<body class="d-flex flex-column min-vh-100">
        
    <div class="container conLogo">
        <h1 class="titulos">A&B Cursos Online</h1>
    </div>
    
    <!--Navbar-->
    <div class="container card">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <!-- Logo de la barra de navegación -->
                <!-- <a class="navbar-brand" href="#">A&J</a> -->
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarOpciones" aria-controls="navbarOpciones" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <!-- Contenido oculto en dispositivos pequeños -->
                <div class="collapse navbar-collapse" id="navbarOpciones">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item border-end">
                            <a class="nav-link active textos-2" aria-current="page" href="landPage.html"> Principal </a>
                        </li>
                        <li class="nav-item border-end">
                            <a class="nav-link active textos-2" aria-current="page" href="perfil.html"> Mi Perfil </a>
                        </li>
                        <li class="nav-item border-end">
                            <a class="nav-link active textos-2" aria-current="page" href="chat.html"> Mis Chats </a>
                        </li>
                        
                        <!-- Desplegable de opciones -->
                        <li class="nav-item dropdown border-end">
                            <a class="nav-link dropdown-toggle textos-2" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Categorías
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item textos-2" href="Busqueda.html">Arte</a></li>
                                <li><a class="dropdown-item textos-2" href="Busqueda.html">Matemáticas</a></li>
                                <li><a class="dropdown-item textos-2" href="Busqueda.html">Programación</a></li>
                                <!--li><hr class="dropdown-divider"></li> 
                                <li><a class="dropdown-item textos-2" href="#">Cerrar sesión</a></li--> <!--style letras rojas-->
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active textos-2" aria-current="page" href="inicioSesion.html">Cerrar Sesión</a>
                        </li>
                    </ul>
                    
                    <!-- Formulario de búsqueda ajustable -->
                    <form class="d-flex w-auto w-md-50 w-lg-50">
                        <input class="form-control me-2 textos-2" type="search" placeholder="Escribe algo.." aria-label="Buscar">
                        <button class="btn btn-outline-dark textos-2" type="submit" formaction="Busqueda.html">Buscar</button>
                    </form>
                </div>
            </div>
        </nav>
    </div>

    <div class="container mt-5">
        <div class="card"> 
            <!--div class="card-header text-center">
                <h3 class="titulos">Niveles del curso</h3>
            </div-->

            <div class="card-body">
                <div class="row">
                    <div class="col-3 d-flex justify-content-end">
                        <img src="IMG/sql.png" alt="Imagen circular" class="img-fluid rounded-circle fotoPerfil">
                    </div>
                    
                    <div class="col-8">
                    <h2 class="titulos1"><?php echo htmlspecialchars($nombre_usuario); ?></h2>
                        <p class="subtitulos1">Rol de Perfil: <?php echo ($rango == 1) ? 'Administrador' : (($rango == 2) ? 'Instructor' :  'Alumno'); ?></p> <!--No ocupas poner un $rango== 3 debido a que la logica lo hace por si misma-->
                        <p class="subtitulos1">Télefono: <?php echo htmlspecialchars($telefono); ?></p>
                        <p class="subtitulos1">Email: <?php echo htmlspecialchars($email); ?></p>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <h2 class="titulos1">Mis Cursos</h2>
    </div>
    
    <div class="container cont-Cursos px-2">
        <div class="row rowCursos gx-5">

            <!--Aquí agregar cada curso-->
            <div class="card col-lg-5 col-md-5 col-sm-11 px-0">
                <div class="row no-gutters">
                    <div class="col-5">
                        <div class="card-body">
                            <h4 class="card-title subtitulos">Nombre del Curso</h4>
                            <p class="subtitulos-categoria small">Autor | Categoría</p>
                            <p class="textos">Información del Curso </p>
                            <p class="textos"> Costo $20.50 </p>
                            <a href="CursoVer.html" class="btn btn-primary btn-sm"> Ver Curso Completo </a>
                        </div>
                    </div>

                    <div class="col-7">
                        <img class="img-fluid h-100 imgCard" src="IMG/sql.png" alt="Imagen del curso">
                    </div>
                </div>
            </div> 

        </div>
    </div>
    <?php if ($rango == 1): // Si es administrador ?>

    <div class="container">
        <h2 class="titulos1">Reportes</h2>
        <p class="subtitulos-categoria">Solo se verá uno dependiendo el tipo de Perfil (Alumno, Profesor o Administrador).</p>
    </div>

    <div class="container">
        <div class="row">
            <div class="col d-flex justify-content-between">
                <a href="Kardex.html" class="btn btn-dark">Kardex</a>
                <a href="reportVenta.html" class="btn btn-dark">Ventas</a>
                <a href="reportUsers.html" class="btn btn-dark">Usuarios</a>
                <a href="crear_categoria.php" class="btn btn-dark">Crear categoria</a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($rango == 2): // Si es instructor ?>
        <div class="container">
        <h2 class="titulos1">Reportes</h2>
        <p class="subtitulos-categoria">Solo se verá uno dependiendo el tipo de Perfil (Alumno, Profesor o Administrador).</p>
    </div>

    <div class="container">
        <div class="row">
            <div class="col d-flex justify-content-between">
                <a href="Kardex.html" class="btn btn-dark">Crear curso</a>
                
            </div>
        </div>
    </div>
        <?php endif; ?>
    <main class="flex-grow-1 container">
    </main>

    <!-- ==== FOOTER ==== -->
    <footer class="footer">
        <div class="container">
            <p>© 2024 A&B Cursos Online. Todos los derechos reservados.</p>
            <div class="social-icons">
                <a href="#"><i class="ri-facebook-fill"></i></a>
                <a href="#"><i class="ri-twitter-fill"></i></a>
                <a href="#"><i class="ri-linkedin-fill"></i></a>
            </div>
        </div>
    </footer>

    <script src="JS/bootstrapJS/bootstrap.bundle.min.js"></script>
</body>
</html>
